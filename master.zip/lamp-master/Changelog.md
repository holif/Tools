###版本`3.0.6`：`Release date:2015/02/25`
更新记录：

* 1、升级 PHP 到版本 5.4.38, 5.5.22；
* 2、升级 phpMyAdmin 到版本 4.3.10；
* 3、升级 MySQL 到版本 5.5.42, 5.6.23；
* 4、升级 MariaDB 到版本 5.5.42, 10.0.16；
* 5、升级 apr-util 到版本 1.5.4；
* 6、升级 httpd 到版本 2.4.12；

###版本`3.0.5`：`Release date:2015/01/29`
更新记录：

* 1、升级 PHP 到版本 5.4.37, 5.5.21；
* 2、升级 phpMyAdmin 到版本 4.3.8；
* 3、升级 libedit 到版本 libedit-20141030-3.1；

###版本`3.0.4`：`Release date:2015/01/17`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.3.7；
* 2、修正获取公网 IP 的备用方式；

###版本`3.0.3`：`Release date:2015/01/08`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.3.6；

###版本`3.0.2`：`Release date:2015/01/06`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.3.5；

###版本`3.0.1`：`Release date:2014/12/29`
更新记录：

* 1、升级 MariaDB 到版本 5.5.41（my_config.h 的编译错误已经被 Fixed）；
* 2、升级 phpMyAdmin 到版本 4.3.4；

###版本`3.0.0`：`Release date:2014/12/19`
更新记录：

* 1、升级 PHP 到版本 5.4.36, 5.5.20；
* 2、升级 phpMyAdmin 到版本 4.3.2；
* 3、优化 MySQL，MariaDB 的 ldconfig 配置；

###版本`2.9.9`：`Release date:2014/12/07`
更新记录：
* 1、升级 MySQL 到版本 5.5.41, 5.6.22；
* 2、优化 MySQL 和 MariaDB 的升级脚本；

###版本`2.9.8`：`Release date:2014/11/30`
更新记录：

* 1、升级 PHP 到版本 5.4.35；
* 2、升级 phpMyAdmin 到版本 4.3.0；
* 3、升级 MariaDB 到版本 10.0.15；

###版本`2.9.7`：`Release date:2014/11/14`
更新记录：

* 1、升级 PHP 到版本 5.5.19；
* 2、升级 phpMyAdmin 到版本 4.2.11；

###版本`2.9.6`：`Release date:2014/10/20`
更新记录：

* 1、升级 PHP 到版本 5.4.34， 5.5.18；

###版本`2.9.5`：`Release date:2014/10/13`
更新记录：
* 1、升级 phpMyAdmin 到版本 4.2.10；

###版本`2.9.4`：`Release date:2014/10/10`
更新记录：
* 1、升级 MariaDB 到版本 5.5.40, 10.0.14；
* 2、升级 phpMyAdmin 到版本 4.2.9.1；

###版本`2.9.3`：`Release date:2014/09/26`
更新记录：
* 1、升级 MySQL 到版本 5.5.40, 5.6.21；
* 2、新增 memcached.sh 脚本，一键安装 memcached 及 memcached 的 PHP 扩展；

###版本`2.9.2`：`Release date:2014/09/25`
更新记录：

* 1、新增 PHP 版本 5.3.29， 5.5.17 支持；
* 2、新增 MySQL 版本 5.5.39 支持；
* 3、优化 MySQL 和 MariaDB 的升级脚本；
* 4、优化 ZendGuardLoader，Xcache，OCI8，ionCube PHP Loader，ImageMagick 脚本，对应 PHP 各版本；
* 5、升级 Xcache 至版本 3.2.0；
* 6、新增 opcache.sh 脚本，一键安装 Zend OPcache；
* 7、新增 GraphicsMagick.sh 脚本，一键安装 gmagick 扩展；

###版本`2.9.1`：`Release date:2014/09/22`
更新记录：

* 1、升级 PHP 到版本 5.4.33；
* 2、升级 phpMyAdmin 到版本 4.2.9；
* 3、升级 ImageMagick 到版本 6.8.9-8；

###版本`2.9.0`：`Release date:2014/09/01`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.2.8；

###版本`2.8.9`：`Release date:2014/08/29`
更新记录：

* 1、升级 PHP 到版本 5.4.32；
* 2、升级 phpMyAdmin 到版本 4.2.7.1；

###版本`2.8.8`：`Release date:2014/08/12`
更新记录：

* 1、支持 CentOS 7；

###版本`2.8.7`：`Release date:2014/08/03`
更新记录：

* 1、升级 MySQL 到版本 5.6.20；
* 2、升级 phpMyAdmin 到版本 4.2.7；
* 3、升级 Apache 到版本 2.4.10；

###版本`2.8.6`：`Release date:2014/07/26`
更新记录：

* 1、升级 PHP 到版本 5.4.31；

###版本`2.8.5`：`Release date:2014/07/18`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.2.6；

###版本`2.8.4`：`Release date:2014/07/12`
更新记录：

* 1、新增 ImageMagick 扩展支持脚本 ImageMagick.sh；
* 2、修正了获取 PHP 5.4 最新版的版本号一个问题（update.sh）；

###版本`2.8.3`：`Release date:2014/06/27`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.2.5；
* 2、升级 PHP 到版本 5.4.30；

###版本`2.8.2`：`Release date:2014/06/24`
更新记录：

* 1、新增安装 MariaDB 10.0 选项；
* 2、优化了 MariaDB 升级脚本 upgrade_mariadb.sh ；

###版本`2.8.1`：`Release date:2014/06/21`
更新记录：

* 1、升级 phpMyAdmin 到版本 4.2.4；

###版本`2.8`：`Release date:2014/06/20`
更新记录：

* 1、新增安装 MariaDB 5.5 选项；
* 2、升级 phpMyAdmin 到版本 4.2.3；
* 3、优化了一些配置文件;

###版本`2.7.3`：`Release date:2014/06/10`
更新记录：

* 1、修正和优化了一些问题`；
* 2、因为 google 被墙的缘故，更改了 xcache 和 pureftpd 安装包的下载链接；

###版本`2.7.2`：`Release date:2014/06/05`
更新记录：

* 1、更改`Xcache`、`Zend Guard Loader`，`OCI8`的配置文件到PHP扫描的目录/usr/local/php/php.d下；
* 2、增加编译`PHP`的模块：bz2,gettext,gmp,pcntl,readline,shmop,xsl
* 3、增加`ionCube`；

###版本`2.7.1`：`Release date:2014/06/04`
更新记录：

* 1、升级`OCI8`到版本`2.0.8`；
* 2、优化探针显示；
* 3、优化`PHP`的配置文件php.ini;

###版本`2.7`：`Release date:2014/05/31`
更新记录：

* 1、升级`PHP`到版本`5.4.29`；
* 2、升级`MySQL`到版本`5.6.19`；
* 3、新增`MySQL`一键升级脚本`upgrade_mysql.sh`；

###版本`2.6.3`：`Release date:2014/05/22`
更新记录：

* 1、升级`phpMyAdmin`到版本`4.2.2`；

###版本`2.6.2`：`Release date:2014/05/14`
更新记录：

* 1、升级`phpMyAdmin`到版本`4.2.1`；

###版本`2.6.1`：`Release date:2014/05/12`
更新记录：

* 1、升级`phpMyAdmin`到版本`4.2.0`；

###版本`2.6`：`Release date:2014/05/03`
更新记录：

* 1、升级`PHP`到版本`5.4.28`；

###版本`2.5`：`Release date:2014/04/28`
更新记录：

* 1、升级`phpMyAdmin`到版本`4.1.14`；
* 2、更改`lamp.sh`中的下载链接；
* 3、更改`update.sh`中的`backup`的下载链接；

###版本`2.4`：`Release date:2014/04/21`
更新记录：

* 1、升级`MySQL`到版本`5.6.17`；
* 2、升级`PHP`到版本`5.4.27`；
* 3、升级`phpMyAdmin`到版本`4.1.13`；


###版本`2.3`：`Release date:2014/03/24`
更新记录：

* 1、升级`phpMyAdmin`到版本`4.1.11`；


###版本`2.2`：`Release date:2014/03/20`
更新记录：

* 1、升级`Apache`到版本`2.4.9`；
* 2、升级`PHP`到版本`5.4.26`；
* 3、升级`phpMyAdmin`到版本`4.1.9`；


###版本`2.2`：`Release date:2014/02/10`
更新记录：

* 1、升级`PHP`到版本`5.4.25`；
* 2、升级`phpMyAdmin`到版本`4.1.7`；


###版本`2.2`：`Release date:2014/02/01`
更新记录：

* 1、升级`Apache`到版本`2.4.7`；
* 2、升级`PHP`到版本`5.4.24`；
* 3、升级`phpMyAdmin`到版本`4.1.6`；
* 4、升级`MySQL`到版本`5.6.16`；
* 5、由于 Google Code 无法再新建文件下载，因此更新安装包的下载链接为七牛云存储的外链。


###版本`2.2`：`Release date:2013/12/18`
更新记录：

* 1、升级`Apache`到版本`2.4.7`；
* 2、升级`PHP`到版本`5.4.23`；
* 3、升级`phpMyAdmin`到版本`4.1.1`；
* 4、升级`Apache`的依赖包`apr`到版本`1.5.0`；
* 5、升级`Apache`的依赖包`apr-util`到版本`1.5.3`；
* 6、升级`re2c`到版本`0.13.6`；

###版本`2.2`：`Release date:2013/12/10`
更新记录：

* 1、升级`phpMyAdmin`到版本为`4.0.10`；
* 2、优化`lamp.sh`脚本`Apache`和`MySQL`的软连接逻辑，使得`webmin`可以直接识别；
* 3、升级`OCI8`的版本至`2.0.6`；

###版本`2.2`：`Release date:2013/11/22`
更新记录：

* 1、升级`phpMyAdmin`到版本为`4.0.9`；
* 2、升级`PHP`到版本为`5.4.22`；
* 3、优化`lamp.sh`脚本代码逻辑，使其充分利用多核处理器的性能，编译更快；

###版本`2.2`：`Release date:2013/11/04`
更新记录：

* 1、升级`phpMyAdmin`到版本为`4.0.8`；
* 2、升级`PHP`到版本为`5.4.21`；
* 3、升级`MySQL`到版本`5.6.14`；
* 4、优化升级脚本`update.sh`的逻辑，修复因官网改版，判断PHP版本出错的问题;
* 5、新增脚本`xcache_3.1.0.sh`。

###版本`2.1`：`Release date:2013/07/24`
更新记录：

* 1、升级`MySQL`到版本`5.6.12`；
* 2、升级`PHP`到版本为`5.4.17`；
* 3、升级`Apache`到版本`2.4.6`；
* 4、升级`phpMyAdmin`到版本`4.0.4.1`；
* 5、升级`Apache`的依赖包`apr`到版本`1.4.8`；
* 6、升级`Xcache`到版本`3.0.3`，其安装脚本名从`xcache_3.0.1.sh`改为`xcache_3.0.3.sh`。


###版本`2.0`：`Release date:2013/05/13`
更新记录：

* 1、升级`phpMyAdmin`到版本为`4.0.0`；
* 2、升级`PHP`到版本为`5.4.15`；
* 3、优化脚本`update.sh`，修复了安装完新版`PHP`后已安装的`extensions`丢失的`bug`。

**备注：**版本号不作调整，依旧为2.0，替换了原来的下载文件。

###版本`2.0`：`Release date:2013/04/28`
更新记录：

* 1、升级`MySQL`版本为`5.6.11`；
* 2、升级`phpMyAdmin`到版本为`3.5.8.1`；
* 3、增加升级`PHP`和`phpMyAdmin`脚本`update.sh`,可以自动检测最新版`PHP`和`phpMyAdmin`供选择升级;
* 4、合并原来禁止`SELINUX`的脚本`disable.sh`到`lamp.sh`中。

###版本`1.3.1`：`Release date:2013/04/13`
更新记录：

* 1、升级`PHP`到版本`5.4.14`。

###版本`1.3`：`Release date:2013/04/11`
更新记录：

* 1、升级`PHP`到版本`5.4.13`；
* 2、升级`MySQL`版本为`5.6.10`；
* 3、升级`phpMyAdmin`到版本为`3.5.8`；
* 4、升级`Apache`到版本为`2.4.4`；
* 5、升级`apr-util`到版本`1.5.2`；
* 6、优化`oci8_oracle`脚本，配置其`extension为no-debug-non-zts-20100525`；
* 7、优化`xcache`脚本，配置其`extension为no-debug-non-zts-20100525`；
* 8、升级`PHP`探针文件到最新版`v0.4.7`；
* 9、因`ZendGuardLoader`只适用于`PHP5.3.x`系列，故在此版本中去除。

###版本`1.2.1`：`Release date:2013/02/22`
更新记录：

* 1、升级`PHP`版本为`5.3.22`；
* 2、升级`phpMyAdmin`版本为`3.5.7`；
* 3、优化`lamp.sh`，增加创建（删除，列出）虚拟主机、创建（删除，列出）ftp用户命令；
* 4、优化`php.ini`配置文件。


###版本`1.2`：`Release date:2013/02/06`
更新记录：

* 1、升级`MySQL`版本为`5.5.30`；
* 2、升级`PHP`版本为`5.3.21`；
* 3、更新探针`p.php`文件;
* 4、升级`Xcache`版本为`2.0.1`(登录`xcache`管理界面：`http://IP地址或域名/xcache`，用户名：`admin`密码：`123456`)；
* 5、增加`Xcache`版本为`3.0.1`的脚本(强烈推荐安装此版本，加速效果显著，登录管理界面地址同上)；
* 6、优化安装脚本判断逻辑。


###版本`1.1`：`Release date:2013/01/30`
更新记录：

* 1、去除`Apache`和`PHP`低版本的安装脚本选择；
* 2、去除`ZendOptimizer 3.3.9`(脚本`zend.sh`) ，`pure-ftpd-1.0.36`。(脚本`pureftpd.sh`)；
* 3、优化`lamp.sh`脚本，以及相关配置文件；
* 4、修改`Apache`的`httpd-vhosts.conf`配置文件，改为单一安装。
* 5、`phpMyAdmin`升级到`3.5.6`，优化配置文件中的默认语言为简体中文。


###版本`1.0`：`Release date:2013/01/14`

###适用环境：

* 系统支持：`CentOS-5 (32bit/64bit)或CentOS-6 (32bit/64bit)`
* 内存要求：`≥256M`

###将会安装:

* 1、`Apache 2.2.22`或`Apache 2.4.3`
* 2、`MySQL 5.5.29`
* 3、`PHP 5.2.17`或`PHP 5.3.20 + ZendGuardLoader`
* 4、`phpMyAdmin 3.5.5`
* 5、`ZendOptimizer 3.3.9` (可选，只适合`PHP 5.2.17`)
* 6、`xcache 1.3.2` (可选)
* 7、`pure-ftpd-1.0.36`（可选）

###安装其它：

* 1、（可选）执行脚本`pureftpd.sh`安装`pure-ftpd-1.0.36`。(命令：`./pureftpd.sh`)
* 2、（可选）执行脚本`zend.sh`安装`ZendOptimizer 3.3.9`。(命令：`./zend.sh`) 注意：不适用于`PHP 5.3.20`
* 3、（建议）执行脚本`xcache.sh`安装`xcache 1.3.2`。(命令：`./xcache.sh`)
* 4、执行脚本`php5.3_oci8_oracle11g.sh`安装`OCI8`扩展以及`oracle-instantclient11.2`（命令：`./php5.3_oci8_oracle11g.sh`）
* 5、执行脚本`php5.3_oci8_oracle10g.sh`安装`OCI8`扩展以及`oracle-instantclient10.2`（命令：`./php5.3_oci8_oracle10g.sh`）

**备注：**4、5两者选其一执行即可（可选）。该脚本是为了使PHP可以连接Oracle数据库。若连接的数据库版本为10.2，则执行5，否则执行4。

